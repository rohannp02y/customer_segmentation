# 📤 How to Upload Your Project to GitHub
### Step-by-Step Guide for Rohan Neupane

---

## STEP 1 — Create a GitHub Account
1. Go to **https://github.com**
2. Click **"Sign up"**
3. Use email: **rohannneupane02@gmail.com**
4. Choose a username (e.g. `rohannneupane02`)
5. Verify your email

---

## STEP 2 — Create a New Repository
1. Log in → click the **"+"** icon (top-right)
2. Select **"New repository"**
3. Fill in:
   - **Repository name:** `customer-segmentation`
   - **Description:** `Mall Customer Segmentation using K-Means Clustering`
   - Set to **Public** ← important for portfolio!
   - ❌ Do NOT check "Add a README file"
4. Click **"Create repository"**

---

## STEP 3 — Install Git

### Windows:
1. Download from **https://git-scm.com/download/win**
2. Install with default settings
3. Open **Git Bash** from Start Menu

### Mac:
Open Terminal and run:
```
xcode-select --install
```

### Verify it worked:
```
git --version
```

---

## STEP 4 — Configure Git (One Time Only)
```
git config --global user.name "Rohan Neupane"
git config --global user.email "rohannneupane02@gmail.com"
```

---

## STEP 5 — Upload the Project

Open Git Bash (Windows) or Terminal (Mac).

Navigate to your project folder:
```
cd path/to/customer-segmentation

# Example Windows:
# cd C:\Users\Rohan\Downloads\customer-segmentation

# Example Mac:
# cd ~/Downloads/customer-segmentation
```

Then run these commands one by one:
```
git init
git add .
git commit -m "Customer Segmentation using K-Means Clustering"
git remote add origin https://github.com/YOUR_USERNAME/customer-segmentation.git
git branch -M main
git push -u origin main
```

⚠️ Replace YOUR_USERNAME with your actual GitHub username!

---

## STEP 6 — Personal Access Token (replaces password)

GitHub no longer accepts your normal password. You need a token:

1. GitHub → click your profile photo → **Settings**
2. Scroll to the bottom → **"Developer settings"**
3. **"Personal access tokens"** → **"Tokens (classic)"**
4. Click **"Generate new token (classic)"**
5. Note: `my-upload-token` | Expiration: 90 days | Check ✅ **repo**
6. Click **"Generate token"**
7. **COPY the token immediately** — you won't see it again!
8. When Git asks for your password → paste the token

---

## STEP 7 — Verify It Worked

Go to:
```
https://github.com/YOUR_USERNAME/customer-segmentation
```

You should see all your files and the README! 🎉

---

## 🔄 How to Update Your Project Later

Whenever you make changes:
```
git add .
git commit -m "describe what you changed"
git push
```

---

## 💼 Portfolio Tips for Freelancing

1. ✏️  Your name & LinkedIn are already in the README — no changes needed!
2. 📌 **Pin the repo** on your GitHub profile so clients see it first
3. 🔗 Add your GitHub link to your LinkedIn: **https://github.com/YOUR_USERNAME**
4. 💬 Share the repo link on LinkedIn as a post to get visibility

---

## ❓ Common Errors & Fixes

| Error | Fix |
|-------|-----|
| `git: command not found` | Install Git from git-scm.com |
| `Authentication failed` | Use your Personal Access Token as the password |
| `Repository not found` | Double-check the username in the remote URL |
| `Updates were rejected` | Run `git pull origin main --allow-unrelated-histories` first |
